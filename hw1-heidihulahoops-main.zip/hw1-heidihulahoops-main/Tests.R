# Use this file to create tests/debug your functions

# Source the functions
source("FunctionsLM.R")